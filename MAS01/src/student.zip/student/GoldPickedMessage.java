package student;

import mas.agents.Message;

public class GoldPickedMessage extends Message {

}
