package student;

public class Constants {
	final static String UP = "up";
	final static String DOWN = "down";
	final static String RIGHT = "right";
	final static String LEFT = "left";
}
