package student;

import mas.agents.Message;

public class ConfirmInNeighborhoodMessage extends Message {

}
